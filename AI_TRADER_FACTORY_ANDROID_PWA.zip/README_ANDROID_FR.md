# AI TRADER FACTORY Android PWA

Version web installable sur Android, adaptée aux écrans pliables Samsung Galaxy Z Fold.

## Installation
1. Héberger ce dossier sur un serveur HTTPS.
2. Ouvrir l'adresse dans Chrome sur le téléphone.
3. Menu ⋮ > Installer l'application (ou Ajouter à l'écran d'accueil).
4. Lancer depuis l'icône AI Trader.

Cette livraison est une PWA, pas un APK natif. Les données sont fictives et le trading réel est désactivé. Pour connecter l'API FastAPI existante, configurer une URL HTTPS et une authentification côté serveur. Ne pas exposer une API de trading sans contrôle d'accès.
